<?php
require_once('utilities.php');
require_once('header.php'); 

?>
<div class="row">
	<div class="large-9 columns">
<?php
echo "Hola fulano, en Español.<br/> ";
echo "Su llamada urgente<br/>";
echo "Usted quiere recibir noticias de: <br/>";

?>
	</div>
</div>
<?php


require_once('footer.php'); 
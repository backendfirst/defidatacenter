<div class="row">
      <div class="large-3 columns">
        <h1><img src="./img/logo.png"/></h1>
      </div>
      <div class="large-9 columns">
        <ul class="right button-group">
          <li><a href="./index.php" class="button">Inicio</a></li>
          <li><a href="./formulario_contacto.php" class="button">Contacto</a></li>
        </ul>
      </div>
    </div>
<?php

echo '
<select>
	<option>Uno</option>
	<option>Dos</option>
</select>
';
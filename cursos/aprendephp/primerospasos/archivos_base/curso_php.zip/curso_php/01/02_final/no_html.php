<?php 
$nombre = "Roberto";
echo $nombre;

?>

<?php
phpinfo();
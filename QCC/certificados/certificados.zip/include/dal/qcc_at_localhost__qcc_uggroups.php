<?php
$dalTableqcc_uggroups = array();
$dalTableqcc_uggroups["GroupID"] = array("type"=>3,"varname"=>"GroupID");
$dalTableqcc_uggroups["Label"] = array("type"=>200,"varname"=>"Label");
	$dalTableqcc_uggroups["GroupID"]["key"]=true;

$dal_info["qcc_at_localhost__qcc_uggroups"] = &$dalTableqcc_uggroups;
?>
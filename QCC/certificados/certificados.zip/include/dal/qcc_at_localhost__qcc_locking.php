<?php
$dalTableqcc_locking = array();
$dalTableqcc_locking["id"] = array("type"=>3,"varname"=>"id");
$dalTableqcc_locking["table"] = array("type"=>200,"varname"=>"table");
$dalTableqcc_locking["startdatetime"] = array("type"=>135,"varname"=>"startdatetime");
$dalTableqcc_locking["confirmdatetime"] = array("type"=>135,"varname"=>"confirmdatetime");
$dalTableqcc_locking["keys"] = array("type"=>200,"varname"=>"keys");
$dalTableqcc_locking["sessionid"] = array("type"=>200,"varname"=>"sessionid");
$dalTableqcc_locking["userid"] = array("type"=>200,"varname"=>"userid");
$dalTableqcc_locking["action"] = array("type"=>3,"varname"=>"action");
	$dalTableqcc_locking["id"]["key"]=true;

$dal_info["qcc_at_localhost__qcc_locking"] = &$dalTableqcc_locking;
?>
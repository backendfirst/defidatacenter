<?php
$dalTableqcc_ugmembers = array();
$dalTableqcc_ugmembers["UserName"] = array("type"=>200,"varname"=>"UserName");
$dalTableqcc_ugmembers["GroupID"] = array("type"=>3,"varname"=>"GroupID");
	$dalTableqcc_ugmembers["UserName"]["key"]=true;
	$dalTableqcc_ugmembers["GroupID"]["key"]=true;

$dal_info["qcc_at_localhost__qcc_ugmembers"] = &$dalTableqcc_ugmembers;
?>
<?php
$dalTableqcc_ugrights = array();
$dalTableqcc_ugrights["TableName"] = array("type"=>200,"varname"=>"TableName");
$dalTableqcc_ugrights["GroupID"] = array("type"=>3,"varname"=>"GroupID");
$dalTableqcc_ugrights["AccessMask"] = array("type"=>200,"varname"=>"AccessMask");
	$dalTableqcc_ugrights["TableName"]["key"]=true;
	$dalTableqcc_ugrights["GroupID"]["key"]=true;

$dal_info["qcc_at_localhost__qcc_ugrights"] = &$dalTableqcc_ugrights;
?>